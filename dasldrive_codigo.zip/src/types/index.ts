export type UserRole = 'CLIENT' | 'ADMIN';

export interface User {
  id: string;
  names: string;
  lastNames: string;
  email: string;
  phone: string;
  role: UserRole;
  createdAt: string;
}

export type VehicleCondition = 'nuevo' | 'usado';

export interface Vehicle {
  id: string;
  sellerId: string;
  images: string[];
  documents: string[]; // URLs or base64
  brand: string;
  model: string;
  year: number;
  condition: VehicleCondition;
  mileage: number;
  engine: string;
  fuel: string;
  city: string;
  price: number;
  description: string; // Max 150 chars
  createdAt: string;
}

export type BankAccountType = 'ahorro' | 'corriente';

export interface BankAccount {
  id: string;
  bank: string;
  accountNumber: string;
  ownerName: string;
  accountType: BankAccountType;
}

export type CopartRequestStatus = 'pendiente_pago_servicio' | 'esperando_aprobacion_servicio' | 'chat_habilitado' | 'esperando_pago_puja' | 'revision_pago_puja' | 'subasta_terminada_ganada' | 'subasta_terminada_perdida';

export interface CopartRequest {
  id: string;
  clientId: string;
  copartLink: string;
  serviceFeeReceipt?: string; // Image URL/b64
  maxBidAmount?: number;
  bidFeeReceipt?: string;
  status: CopartRequestStatus;
  createdAt: string;
  updatedAt: string;
}

export interface ChatMessage {
  id: string;
  copartRequestId: string;
  senderId: string;
  senderRole: UserRole;
  text: string;
  timestamp: string;
}

export interface Suggestion {
  id: string;
  name?: string;
  email: string;
  message: string;
  createdAt: string;
}
