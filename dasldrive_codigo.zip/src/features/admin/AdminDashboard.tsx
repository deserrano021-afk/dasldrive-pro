import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Users,
  Car,
  Gavel,
  Building,
  Settings,
  MessageSquare,
  LogOut
} from 'lucide-react';
import { AdminUsers } from './AdminUsers';
import { AdminBanks } from './AdminBanks';
import { AdminSuggestions } from './AdminSuggestions';
import { AdminCopart } from './AdminCopart';
import { AdminVehicles } from './AdminVehicles';
import { AuthService } from '../../services/authService';
import type { User } from '../../types';

export function AdminDashboard() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('copart');
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    const currentUser = AuthService.getCurrentUser();
    if (!currentUser || currentUser.role !== 'ADMIN') {
      navigate('/login');
    } else {
      setUser(currentUser);
    }
  }, [navigate]);

  if (!user) return null;

  const handleLogout = () => {
    AuthService.logout();
    navigate('/');
  };

  const navItems = [
    { id: 'copart', label: 'Solicitudes Copart', icon: <Gavel size={18} /> },
    { id: 'vehicles', label: 'Vehículos Publicados', icon: <Car size={18} /> },
    { id: 'users', label: 'Usuarios', icon: <Users size={18} /> },
    { id: 'banks', label: 'Cuentas Bancarias', icon: <Building size={18} /> },
    { id: 'suggestions', label: 'Sugerencias', icon: <MessageSquare size={18} /> },
  ];

  return (
    <div className="min-h-screen bg-[#0a0b0e] flex">
      {/* Admin Sidebar */}
      <aside className="w-64 border-r border-white/10 bg-[#0f1115] flex flex-col">
        <div className="p-6 border-b border-white/10">
          <h2 className="text-xl font-heading font-bold flex items-center gap-2">
            <Settings className="text-primary" /> Panel Admin
          </h2>
          <p className="text-xs text-secondary mt-1">DASLDRIVE Control Center</p>
        </div>

        <nav className="flex-1 py-4">
          {navItems.map(item => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-6 py-3 text-sm transition-colors ${
                activeTab === item.id 
                  ? 'bg-primary/10 text-primary border-r-2 border-primary' 
                  : 'text-secondary hover:bg-white/5 hover:text-white'
              }`}
            >
              {item.icon}
              {item.label}
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-white/10">
          <button 
            onClick={handleLogout}
            className="flex items-center gap-2 text-muted hover:text-danger w-full px-2 py-2 text-sm transition-colors"
          >
            <LogOut size={16} /> Cerrar Sesión
          </button>
        </div>
      </aside>

      {/* Admin Main Content */}
      <main className="flex-1 p-8 overflow-y-auto">
        <div className="max-w-6xl mx-auto">
          <header className="mb-8">
            <h1 className="text-3xl font-heading font-bold">
              {navItems.find(i => i.id === activeTab)?.label}
            </h1>
            <p className="text-secondary mt-1">Gestión y control de plataforma.</p>
          </header>

          {/* Main Content Area */}
          <div className="bg-[#16181d] border border-white/10 rounded-xl p-6 min-h-[500px]">
            {activeTab === 'copart' && <AdminCopart />}
            {activeTab === 'vehicles' && <AdminVehicles />}
            {activeTab === 'users' && <AdminUsers />}
            {activeTab === 'banks' && <AdminBanks />}
            {activeTab === 'suggestions' && <AdminSuggestions />}
          </div>
        </div>
      </main>
    </div>
  );
}
