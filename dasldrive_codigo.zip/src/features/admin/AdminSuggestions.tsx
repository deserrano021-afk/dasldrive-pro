import { useState, useEffect } from 'react';
import { MessageSquare, Trash2 } from 'lucide-react';
import { DbService } from '../../services/dbService';
import type { Suggestion } from '../../types';

export function AdminSuggestions() {
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);

  useEffect(() => {
    setSuggestions(DbService.getSuggestions());
  }, []);

  const handleDelete = (id: string) => {
    // We didn't create a delete helper in DbService yet, manipulating localStorage directly as fallback
    const filtered = suggestions.filter(s => s.id !== id);
    localStorage.setItem('dasldrive_suggestions', JSON.stringify(filtered));
    setSuggestions(filtered);
  };

  return (
    <div className="animate-fade-in">
      <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
        <MessageSquare size={24} className="text-primary" /> Buzón de Sugerencias
      </h2>

      <div className="grid gap-6 max-w-4xl">
        {suggestions.length === 0 ? (
          <p className="text-muted bg-white/5 p-6 rounded-lg text-center border border-white/10">No hay sugerencias en la bandeja de entrada.</p>
        ) : (
          suggestions.map(s => (
            <div key={s.id} className="bg-[#0f1115] p-6 rounded-xl border border-white/10 relative group">
              <button 
                onClick={() => handleDelete(s.id)}
                className="absolute top-4 right-4 text-muted hover:text-danger opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <Trash2 size={18} />
              </button>
              
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="font-bold text-white">{s.name || 'Usuario Anónimo'}</h3>
                  <p className="text-sm text-primary">{s.email}</p>
                </div>
                <div className="text-xs text-muted">
                  {new Date(s.createdAt).toLocaleDateString()} {new Date(s.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </div>
              </div>
              
              <div className="text-sm text-secondary bg-black/20 p-4 rounded-lg border border-white/5 whitespace-pre-wrap">
                {s.message}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
