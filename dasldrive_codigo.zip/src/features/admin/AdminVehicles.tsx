import { useState, useEffect } from 'react';
import { X, FileText } from 'lucide-react';
import { DbService } from '../../services/dbService';
import type { Vehicle } from '../../types';
import { Button } from '../../components/Button';

export function AdminVehicles() {
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);

  useEffect(() => {
    setVehicles(DbService.getVehicles());
  }, []);

  const handleDelete = (id: string) => {
    // Basic mock deletion. A real app would have status="pending_review" etc.
    const filtered = vehicles.filter(v => v.id !== id);
    localStorage.setItem('dasldrive_vehicles', JSON.stringify(filtered));
    setVehicles(filtered);
  };

  return (
    <div className="animate-fade-in">
      <h2 className="text-xl font-bold mb-6">Vehículos Publicados ({vehicles.length})</h2>

      <div className="grid gap-6">
        {vehicles.length === 0 ? (
          <p className="text-muted p-6 border border-white/10 rounded-xl text-center">No hay vehículos publicados.</p>
        ) : (
          vehicles.map(v => (
            <div key={v.id} className="bg-[#0f1115] border border-white/10 rounded-xl p-4 flex flex-col md:flex-row gap-6">
              <div className="w-full md:w-48 h-32 rounded-lg overflow-hidden flex-shrink-0 bg-black/20">
                <img src={v.images[0]} alt={v.model} className="w-full h-full object-cover" />
              </div>
              
              <div className="flex-1">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h3 className="text-lg font-bold">{v.brand} {v.model} <span className="text-muted font-normal text-sm">({v.year})</span></h3>
                    <p className="text-accent font-semibold">${v.price.toLocaleString()}</p>
                  </div>
                  <div className="text-xs text-secondary bg-white/5 px-2 py-1 rounded border border-white/10">
                    ID: {v.id}
                  </div>
                </div>
                
                <p className="text-sm text-secondary mb-4 line-clamp-2">{v.description}</p>
                
                {v.documents && v.documents.length > 0 && (
                  <div className="mb-4">
                    <p className="text-xs text-muted mb-2">Documentos Adjuntos (Privados):</p>
                    <div className="flex flex-wrap gap-2">
                      {v.documents.map((doc, i) => (
                        <div key={i} className="flex items-center gap-1 text-xs bg-white/10 px-2 py-1 rounded text-primary">
                          <FileText size={12} /> {doc}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                
                <div className="flex justify-end gap-3 mt-auto">
                  <Button variant="outline" size="sm" onClick={() => window.open(`/vehiculo/${v.id}`, '_blank')}>
                    Ver en Portal
                  </Button>
                  <Button variant="outline" size="sm" className="text-danger border-danger hover:bg-danger/10" onClick={() => handleDelete(v.id)}>
                    <X size={16} className="mr-1" /> Eliminar Publicación
                  </Button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
