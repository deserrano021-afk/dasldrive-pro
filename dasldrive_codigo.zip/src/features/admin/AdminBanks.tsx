import { useState, useEffect } from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { Button } from '../../components/Button';
import { Input } from '../../components/Input';
import { DbService } from '../../services/dbService';
import type { BankAccount, BankAccountType } from '../../types';

export function AdminBanks() {
  const [banks, setBanks] = useState<BankAccount[]>([]);
  const [isAdding, setIsAdding] = useState(false);
  
  const [formData, setFormData] = useState({
    bank: '',
    accountNumber: '',
    accountType: 'ahorro' as BankAccountType,
    ownerName: ''
  });

  useEffect(() => {
    setBanks(DbService.getBankAccounts());
  }, []);

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    const newBank: BankAccount = {
      id: `bnk_${Date.now()}`,
      ...formData
    };
    DbService.saveBankAccount(newBank);
    setBanks([...banks, newBank]);
    setIsAdding(false);
    setFormData({ bank: '', accountNumber: '', accountType: 'ahorro', ownerName: '' });
  };

  const handleDelete = (id: string) => {
    DbService.deleteBankAccount(id);
    setBanks(banks.filter(b => b.id !== id));
  };

  return (
    <div className="animate-fade-in">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold">Cuentas Bancarias Disponibles</h2>
        <Button onClick={() => setIsAdding(!isAdding)} leftIcon={<Plus size={18} />}>
          {isAdding ? 'Cancelar' : 'Añadir Cuenta'}
        </Button>
      </div>

      {isAdding && (
        <div className="bg-white/5 p-6 rounded-xl border border-white/10 mb-8">
          <h3 className="font-semibold mb-4">Nueva Cuenta Bancaria</h3>
          <form onSubmit={handleAdd} className="grid md:grid-cols-2 gap-4">
            <Input required label="Banco" placeholder="Ej. Banco de Honduras" value={formData.bank} onChange={e => setFormData({...formData, bank: e.target.value})} />
            <Input required label="Número de Cuenta" placeholder="000000000" value={formData.accountNumber} onChange={e => setFormData({...formData, accountNumber: e.target.value})} />
            
            <div>
              <label className="text-sm text-secondary mb-2 block">Tipo de Cuenta</label>
              <select 
                className="base-input w-full" 
                value={formData.accountType}
                onChange={e => setFormData({...formData, accountType: e.target.value as BankAccountType})}
              >
                <option value="ahorro">Ahorro</option>
                <option value="corriente">Cheques / Corriente</option>
              </select>
            </div>

            <Input required label="Nombre del Titular" placeholder="Ej. DASLDRIVE S.A" value={formData.ownerName} onChange={e => setFormData({...formData, ownerName: e.target.value})} />
            
            <div className="md:col-span-2 flex justify-end">
              <Button type="submit">Guardar Cuenta</Button>
            </div>
          </form>
        </div>
      )}

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {banks.length === 0 ? (
          <p className="text-muted col-span-full">Aún no has configurado ninguna cuenta bancaria.</p>
        ) : (
          banks.map(bank => (
            <div key={bank.id} className="bg-[#0f1115] p-5 rounded-xl border border-white/10 relative group">
              <button 
                onClick={() => handleDelete(bank.id)}
                className="absolute top-4 right-4 text-muted hover:text-danger opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <Trash2 size={18} />
              </button>
              <div className="font-bold text-lg mb-1">{bank.bank}</div>
              <div className="font-mono text-primary mb-2">{bank.accountNumber}</div>
              <div className="text-sm text-secondary mb-1">Tipo: <span className="text-white">{bank.accountType}</span></div>
              <div className="text-sm text-secondary">Titular: <span className="text-white">{bank.ownerName}</span></div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
