import { useState, useEffect } from 'react';
import type { User } from '../../types';
import { AuthService } from '../../services/authService';

export function AdminUsers() {
  const [users, setUsers] = useState<User[]>([]);

  useEffect(() => {
    // Read from localStorage (using our mock DB service trick since we didn't expose getUsers on DbService directly)
    // Actually, users are stored via AuthService, let's expose a helper or read directly.
    // Read from localStorage via AuthService
    const allUsers = AuthService.getAllUsers?.() || JSON.parse(localStorage.getItem('dasldrive_users') || '[]');
    setUsers(allUsers);
  }, []);

  return (
    <div className="animate-fade-in">
      <h2 className="text-xl font-bold mb-6">Gestión de Usuarios ({users.length})</h2>
      
      <div className="bg-[#0f1115] rounded-xl border border-white/10 overflow-hidden">
        <table className="w-full text-left text-sm">
          <thead className="bg-white/5 border-b border-white/10">
            <tr>
              <th className="p-4 font-semibold">Usuario</th>
              <th className="p-4 font-semibold">Contacto</th>
              <th className="p-4 font-semibold">Rol</th>
              <th className="p-4 font-semibold">Registro</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {users.length === 0 ? (
              <tr>
                <td colSpan={4} className="p-4 text-center text-muted">No hay usuarios registrados.</td>
              </tr>
            ) : (
              users.map(u => (
                <tr key={u.id} className="hover:bg-white/5 transition-colors">
                  <td className="p-4">
                    <div className="font-medium text-white">{u.names} {u.lastNames}</div>
                    <div className="text-xs text-muted font-mono mt-1">{u.id}</div>
                  </td>
                  <td className="p-4">
                    <div>{u.email}</div>
                    <div className="text-muted">{u.phone}</div>
                  </td>
                  <td className="p-4">
                    <span className={`px-2 py-1 rounded text-xs font-semibold ${
                      u.role === 'ADMIN' ? 'bg-accent/20 text-accent' : 'bg-white/10 text-white'
                    }`}>
                      {u.role}
                    </span>
                  </td>
                  <td className="p-4 text-muted">
                    {new Date(u.createdAt).toLocaleDateString()}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
