import { useState, useEffect } from 'react';
import { DbService } from '../../services/dbService';
import { Button } from '../../components/Button';
import type { CopartRequest, ChatMessage, CopartRequestStatus } from '../../types';
import { cn } from '../../utils/cn';

export function AdminCopart() {
  const [requests, setRequests] = useState<CopartRequest[]>([]);
  const [selectedReq, setSelectedReq] = useState<CopartRequest | null>(null);
  const [chatMsgs, setChatMsgs] = useState<ChatMessage[]>([]);
  const [newMsg, setNewMsg] = useState('');

  useEffect(() => {
    setRequests(DbService.getCopartRequests());
    
    // Poll for updates in the list and active chat
    const interval = setInterval(() => {
      setRequests(DbService.getCopartRequests());
      if (selectedReq) {
        setChatMsgs(DbService.getChats(selectedReq.id));
      }
    }, 2000);
    return () => clearInterval(interval);
  }, [selectedReq]);

  // Load chat on select
  useEffect(() => {
    if (selectedReq) {
      setChatMsgs(DbService.getChats(selectedReq.id));
    }
  }, [selectedReq]);

  const updateStatus = (reqId: string, status: CopartRequestStatus) => {
    const req = requests.find(r => r.id === reqId);
    if (req) {
      const updated = { ...req, status, updatedAt: new Date().toISOString() };
      DbService.updateCopartRequest(updated);
      setRequests(prev => prev.map(r => r.id === reqId ? updated : r));
      if (selectedReq?.id === reqId) setSelectedReq(updated);
    }
  };

  const handleSendMsg = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMsg.trim() || !selectedReq) return;
    
    const msg: ChatMessage = {
      id: `msg_${Date.now()}`,
      copartRequestId: selectedReq.id,
      senderId: 'admin_1', // Using mock admin ID
      senderRole: 'ADMIN',
      text: newMsg,
      timestamp: new Date().toISOString()
    };
    DbService.saveChatMessage(selectedReq.id, msg);
    setChatMsgs(prev => [...prev, msg]);
    setNewMsg('');
  };

  return (
    <div className="grid lg:grid-cols-3 gap-6 animate-fade-in h-[calc(100vh-200px)]">
      {/* Solicitudes List */}
      <div className="lg:col-span-1 border border-white/10 rounded-xl bg-[#0f1115] flex flex-col overflow-hidden">
        <div className="p-4 border-b border-white/10 bg-white/5 font-semibold">
          Solicitudes Activas
        </div>
        <div className="flex-1 overflow-y-auto p-2 space-y-2">
          {requests.length === 0 && <p className="text-center text-muted p-4 text-sm">No hay solicitudes.</p>}
          {requests.map(req => (
            <button
              key={req.id}
              onClick={() => setSelectedReq(req)}
              className={cn(
                "w-full text-left p-3 rounded-lg text-sm transition-colors border",
                selectedReq?.id === req.id 
                  ? "bg-primary/10 border-primary text-white" 
                  : "bg-white/5 border-transparent text-secondary hover:bg-white/10 hover:text-white"
              )}
            >
              <div className="font-semibold mb-1 truncate">{req.id}</div>
              <div className="text-xs capitalize text-muted bg-black/30 px-2 py-1 inline-block rounded">
                {(req.status || '').replace(/_/g, ' ')}
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Details & Chat */}
      <div className="lg:col-span-2 border border-white/10 rounded-xl bg-[#0f1115] flex flex-col overflow-hidden">
        {selectedReq ? (
          <>
            <div className="p-4 border-b border-white/10 bg-white/5 flex flex-col md:flex-row gap-4 justify-between">
              <div>
                <h3 className="font-bold">Detalles Solicitud: <span className="text-primary">{selectedReq.id}</span></h3>
                <a href={selectedReq.copartLink} target="_blank" rel="noreferrer" className="text-xs text-accent hover:underline">Ver Vehículo Copart</a>
              </div>
              
              {/* Admin Actions based on Status */}
              <div className="flex gap-2">
                {selectedReq.status === 'esperando_aprobacion_servicio' && (
                  <Button size="sm" onClick={() => updateStatus(selectedReq.id, 'chat_habilitado')}>
                    Aprobar Pago Servicio
                  </Button>
                )}
                {selectedReq.status === 'revision_pago_puja' && (
                  <Button size="sm" onClick={() => updateStatus(selectedReq.id, 'subasta_terminada_ganada')}>
                    Marcar Ganada
                  </Button>
                )}
                {selectedReq.status === 'revision_pago_puja' && (
                  <Button size="sm" variant="outline" className="text-danger border-danger hover:bg-danger/20" onClick={() => updateStatus(selectedReq.id, 'subasta_terminada_perdida')}>
                    Marcar Perdida
                  </Button>
                )}
              </div>
            </div>

            {/* Receipts Viewing Area */}
            {(selectedReq.serviceFeeReceipt || selectedReq.bidFeeReceipt) && (
              <div className="p-4 border-b border-white/10 flex gap-4 bg-black/20 overflow-x-auto">
                {selectedReq.serviceFeeReceipt && (
                  <div className="flex-shrink-0">
                    <p className="text-xs text-muted mb-1">Comprobante Servicio:</p>
                    <img src={selectedReq.serviceFeeReceipt} alt="Recibo" className="h-24 w-auto rounded border border-white/20" />
                  </div>
                )}
                {selectedReq.bidFeeReceipt && (
                  <div className="flex-shrink-0">
                    <p className="text-xs text-muted mb-1">Comprobante Puja (${selectedReq.maxBidAmount}):</p>
                    <img src={selectedReq.bidFeeReceipt} alt="Recibo Puja" className="h-24 w-auto rounded border border-white/20" />
                  </div>
                )}
              </div>
            )}

            {/* Chat Area */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
               {chatMsgs.length === 0 ? (
                 <p className="text-center text-muted text-sm mt-10">
                   Inicia la conversación con el cliente.
                 </p>
               ) : (
                 chatMsgs.map(msg => (
                   <div key={msg.id} className={cn("flex flex-col max-w-[80%]", msg.senderRole === 'ADMIN' ? "ml-auto items-end" : "mr-auto items-start")}>
                     <span className="text-[10px] text-muted mb-1 px-1">
                       {msg.senderRole === 'ADMIN' ? 'Tú (Soporte)' : 'Cliente'} • {new Date(msg.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                     </span>
                     <div className={cn(
                       "p-3 rounded-2xl text-sm",
                       msg.senderRole === 'ADMIN' 
                         ? "bg-white/10 text-white rounded-tr-sm border border-white/5" 
                         : "bg-primary text-white rounded-tl-sm"
                     )}>
                       {msg.text}
                     </div>
                   </div>
                 ))
               )}
             </div>
             
             {/* Chat Input */}
             {['chat_habilitado', 'esperando_pago_puja', 'revision_pago_puja'].includes(selectedReq.status) && (
               <div className="p-4 border-t border-white/10 bg-black/20">
                 <form onSubmit={handleSendMsg} className="flex gap-2">
                   <input 
                     value={newMsg}
                     onChange={e => setNewMsg(e.target.value)}
                     placeholder="Escribe al cliente..."
                     className="flex-1 bg-white/5 border border-white/10 rounded-md px-4 py-2 text-sm text-white focus:outline-none focus:border-primary"
                   />
                   <Button type="submit">Enviar</Button>
                 </form>
               </div>
             )}
          </>
        ) : (
          <div className="m-auto text-muted text-sm">Selecciona una solicitud para ver detalles y chatear.</div>
        )}
      </div>
    </div>
  );
}
