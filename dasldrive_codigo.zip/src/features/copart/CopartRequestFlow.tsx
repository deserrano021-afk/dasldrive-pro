import { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ShieldCheck, Banknote, Upload, MessageCircle, AlertCircle, ArrowLeft } from 'lucide-react';
import { Card } from '../../components/Card';
import { Button } from '../../components/Button';
import { Input } from '../../components/Input';
import { AuthService } from '../../services/authService';
import { DbService } from '../../services/dbService';
import type { CopartRequest, BankAccount, ChatMessage } from '../../types';
import { cn } from '../../utils/cn';

export function CopartRequestFlow() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const user = AuthService.getCurrentUser();
  
  const [request, setRequest] = useState<CopartRequest | null>(null);
  const [banks, setBanks] = useState<BankAccount[]>([]);
  const [chatMsgs, setChatMsgs] = useState<ChatMessage[]>([]);
  const [newMsg, setNewMsg] = useState('');
  
  const receiptRef = useRef<HTMLInputElement>(null);
  const [isUpdating, setIsUpdating] = useState(false);
  const [maxBidInput, setMaxBidInput] = useState('');

  // Initial data load
  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }
    const req = DbService.getCopartRequests().find((r: CopartRequest) => r.id === id);
    if (!req || req.clientId !== user.id) {
      navigate('/copart');
      return;
    }
    setRequest(req);
    setBanks(DbService.getBankAccounts());
    setChatMsgs(DbService.getChats(req.id));
    if (req.maxBidAmount) setMaxBidInput(req.maxBidAmount.toString());

    // Mock polling for updates
    const interval = setInterval(() => {
      const latestReq = DbService.getCopartRequests().find((r: CopartRequest) => r.id === id);
      if (latestReq) setRequest(latestReq);
      setChatMsgs(DbService.getChats(id!));
    }, 2000);
    return () => clearInterval(interval);
  }, [id, user, navigate]);

  if (!request || !user) return <div className="container py-20 text-center">Cargando...</div>;

  const updateStatus = (updates: Partial<CopartRequest>) => {
    setIsUpdating(true);
    setTimeout(() => {
      const newReq = { ...request, ...updates, updatedAt: new Date().toISOString() };
      DbService.updateCopartRequest(newReq);
      setRequest(newReq);
      setIsUpdating(false);
    }, 800);
  };

  const handleReceiptUpload = (e: React.ChangeEvent<HTMLInputElement>, isBidFee: boolean = false) => {
    if (e.target.files && e.target.files.length > 0) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (isBidFee) {
          updateStatus({ bidFeeReceipt: reader.result as string, status: 'revision_pago_puja' });
        } else {
          updateStatus({ serviceFeeReceipt: reader.result as string, status: 'esperando_aprobacion_servicio' });
        }
      };
      reader.readAsDataURL(e.target.files[0]);
    }
  };

  const handleSendMsg = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMsg.trim()) return;
    
    const msg: ChatMessage = {
      id: `msg_${Date.now()}`,
      copartRequestId: request.id,
      senderId: user.id,
      senderRole: user.role,
      text: newMsg,
      timestamp: new Date().toISOString()
    };
    DbService.saveChatMessage(request.id, msg);
    setChatMsgs(prev => [...prev, msg]);
    setNewMsg('');
  };

  const handleMaxBidSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(maxBidInput);
    if (val > 0) {
      updateStatus({ maxBidAmount: val, status: 'esperando_pago_puja' });
    }
  };

  return (
    <div className="container py-8 max-w-4xl">
      <button onClick={() => navigate('/copart')} className="inline-flex items-center text-sm text-secondary hover:text-white mb-6 transition-colors">
        <ArrowLeft size={16} className="mr-1" /> Volver a Panel Copart
      </button>

      <div className="mb-8 flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
        <div>
          <h1 className="text-2xl font-heading font-bold flex items-center gap-2">
            Solicitud Copart <span className="text-primary text-base px-3 py-1 bg-primary/20 rounded-full">{request.id}</span>
          </h1>
          <a href={request.copartLink} target="_blank" rel="noreferrer" className="text-accent text-sm hover:underline mt-1 inline-block">
            {request.copartLink}
          </a>
        </div>
        <div className="px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-sm">
          Estado: <span className="font-semibold text-white ml-2">
            {request.status.replace(/_/g, ' ').toUpperCase()}
          </span>
        </div>
      </div>

      <div className="space-y-6">
        {/* Phase 1: Service Fee Payment */}
        {request.status === 'pendiente_pago_servicio' && (
          <Card className="p-6 md:p-8 animate-fade-in border-warning/30">
            <h2 className="text-xl font-bold mb-2 flex items-center gap-2 text-warning">
              <Banknote size={24} /> Paso 1: Pago de Servicio de Intermediación
            </h2>
            <p className="text-secondary mb-6">
              Para habilitar el chat con un agente y proceder a planificar la puja, debes transferir la tarifa base del servicio ($50.00 USD o equivalente).
            </p>

            <div className="grid md:grid-cols-2 gap-8 mb-6">
              <div>
                <h3 className="font-semibold mb-3">Cuentas Bancarias Disponibles</h3>
                {banks.length === 0 ? (
                  <p className="text-muted text-sm italic">El administrador aún no ha configurado cuentas bancarias.</p>
                ) : (
                   <div className="space-y-3">
                     {banks.map(b => (
                       <div key={b.id} className="p-3 bg-white/5 rounded-lg border border-white/10 text-sm">
                         <div className="font-semibold text-primary">{b.bank}</div>
                         <div className="text-white font-mono my-1">{b.accountNumber} ({b.accountType})</div>
                         <div className="text-muted text-xs">Titular: {b.ownerName}</div>
                       </div>
                     ))}
                   </div>
                )}
              </div>
              <div className="bg-white/5 p-6 rounded-xl flex flex-col justify-center items-center text-center">
                <ShieldCheck size={40} className="text-accent mb-4" />
                <h3 className="font-semibold mb-2">Sube tu comprobante de pago</h3>
                <p className="text-xs text-muted mb-4 max-w-[250px]">
                  Un administrador revisará el comprobante (formato imagen) y habilitará el chat.
                </p>
                <input type="file" accept="image/*" className="hidden" ref={receiptRef} onChange={(e) => handleReceiptUpload(e, false)} />
                <Button isLoading={isUpdating} onClick={() => receiptRef.current?.click()} leftIcon={<Upload size={18} />}>
                  Subir Comprobante
                </Button>
              </div>
            </div>
          </Card>
        )}

        {/* Phase 1.5: Waiting for Admin Approval */}
        {request.status === 'esperando_aprobacion_servicio' && (
          <Card className="p-8 text-center animate-fade-in">
             <div className="w-16 h-16 bg-warning/20 text-warning rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
               <AlertCircle size={32} />
             </div>
             <h2 className="text-xl font-bold mb-2">Comprobante Enviado</h2>
             <p className="text-secondary max-w-sm mx-auto">
               El administrador está verificando tu pago. Una vez aprobado, el chat directo se habilitará aquí mismo. Por favor, espera.
             </p>
          </Card>
        )}

        {/* Phase 2: Active Chat / Setup Bid */}
        {(['chat_habilitado', 'esperando_pago_puja', 'revision_pago_puja'].includes(request.status) || request.status.startsWith('subasta_terminada')) && (
          <div className="grid lg:grid-cols-3 gap-6 animate-fade-in">
            {/* Action Panel */}
            <div className="lg:col-span-1 space-y-6">
              {request.status === 'chat_habilitado' && (
                <Card className="p-6">
                  <h3 className="font-semibold mb-4 border-b border-white/10 pb-2">Definir Monto de Puja</h3>
                  <p className="text-xs text-secondary mb-4">
                    Comunícate en el chat con el administrador para acordar tu monto máximo a pujar. Cuando estés listo, ingrésalo aquí.
                  </p>
                  <form onSubmit={handleMaxBidSubmit} className="space-y-3">
                    <Input 
                      type="number" 
                      placeholder="Monto ($)" 
                      value={maxBidInput}
                      onChange={(e) => setMaxBidInput(e.target.value)}
                      required
                    />
                    <Button type="submit" fullWidth isLoading={isUpdating}>
                      Fijar Monto Máximo
                    </Button>
                  </form>
                </Card>
              )}

              {request.status === 'esperando_pago_puja' && (
                <Card className="p-6 border-accent/30">
                  <h3 className="font-semibold text-accent mb-4 border-b border-white/10 pb-2">Pago de Participación</h3>
                  <p className="text-xs text-secondary mb-4">
                    Has definido el monto en <span className="text-white font-bold">${request.maxBidAmount}</span>. Para participar en la subasta, debes transferir este monto a las cuentas indicadas.
                  </p>
                  <input type="file" accept="image/*" className="hidden" ref={receiptRef} onChange={(e) => handleReceiptUpload(e, true)} />
                  <Button fullWidth onClick={() => receiptRef.current?.click()} leftIcon={<Upload size={18} />}>
                    Subir Comprobante de Puja
                  </Button>
                </Card>
              )}

              {request.status === 'revision_pago_puja' && (
                <Card className="p-6">
                  <h3 className="font-semibold mb-2">Pago en revisión</h3>
                  <p className="text-sm text-muted">El administrador está revisando el comprobante de puja. Pronto participaremos en la subasta.</p>
                </Card>
              )}
              
              {request.status === 'subasta_terminada_ganada' && (
                <Card className="p-6 bg-accent/10 border-accent/30">
                  <h3 className="text-xl font-bold text-accent mb-2">¡Felicidades!</h3>
                  <p className="text-sm">Ganaste la subasta del vehículo. Revisa el chat para coordinar la entrega.</p>
                </Card>
              )}
              
              {request.status === 'subasta_terminada_perdida' && (
                <Card className="p-6 bg-danger/10 border-danger/30">
                  <h3 className="text-xl font-bold text-danger mb-2">No se ganó</h3>
                  <p className="text-sm mb-4">La subasta superó el monto establecido.</p>
                  <p className="text-sm font-semibold mb-2">¿Desea intentar con otro vehículo?</p>
                  <Button fullWidth onClick={() => navigate('/copart')}>Enviar nuevo enlace</Button>
                </Card>
              )}
            </div>

            {/* Chat Box */}
            <Card className="lg:col-span-2 flex flex-col h-[500px]">
              <div className="p-4 border-b border-white/10 flex items-center gap-2">
                <MessageCircle className="text-primary" />
                <h3 className="font-semibold">Chat con Soporte</h3>
              </div>
              
              <div className="flex-1 overflow-y-auto p-4 space-y-4">
                {chatMsgs.length === 0 ? (
                  <p className="text-center text-muted text-sm mt-10">
                    El chat está habilitado. Escribe un mensaje para comenzar.
                  </p>
                ) : (
                  chatMsgs.map(msg => (
                    <div key={msg.id} className={cn("flex flex-col max-w-[80%]", msg.senderRole === 'CLIENT' ? "ml-auto items-end" : "mr-auto items-start")}>
                      <span className="text-[10px] text-muted mb-1 px-1">
                        {msg.senderRole === 'CLIENT' ? 'Tú' : 'Admin'} • {new Date(msg.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                      </span>
                      <div className={cn(
                        "p-3 rounded-2xl text-sm",
                        msg.senderRole === 'CLIENT' 
                          ? "bg-primary text-white rounded-tr-sm" 
                          : "bg-white/10 text-white rounded-tl-sm border border-white/5"
                      )}>
                        {msg.text}
                      </div>
                    </div>
                  ))
                )}
              </div>

              <div className="p-4 border-t border-white/10 mt-auto bg-black/20">
                <form onSubmit={handleSendMsg} className="flex gap-2">
                  <Input 
                    value={newMsg}
                    onChange={e => setNewMsg(e.target.value)}
                    placeholder="Escribe tu mensaje..."
                    className="flex-1"
                  />
                  <Button type="submit">Enviar</Button>
                </form>
              </div>
            </Card>
          </div>
        )}
      </div>

    </div>
  );
}
