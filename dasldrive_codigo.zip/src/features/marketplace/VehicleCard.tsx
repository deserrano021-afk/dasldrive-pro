import { Link } from 'react-router-dom';
import { MapPin, Settings, Fuel, Calendar, ArrowRight } from 'lucide-react';
import type { Vehicle } from '../../types';
import { Card } from '../../components/Card';
import { Button } from '../../components/Button';

export function VehicleCard({ vehicle }: { vehicle: Vehicle }) {
  // Use a placeholder if no images
  const imageSrc = vehicle.images.length > 0 
    ? vehicle.images[0] 
    : 'https://images.unsplash.com/photo-1549317661-bd32c8ce0be2?q=80&w=600&h=400&auto=format&fit=crop';

  return (
    <Card className="group overflow-hidden flex flex-col h-full hover:border-primary/50">
      <div className="relative h-48 overflow-hidden">
        <img 
          src={imageSrc} 
          alt={`${vehicle.brand} ${vehicle.model}`} 
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute top-3 right-3 bg-black/70 backdrop-blur-md px-3 py-1 rounded-full text-xs font-semibold uppercase text-white border border-white/10">
          {vehicle.condition}
        </div>
      </div>
      
      <div className="p-5 flex-1 flex flex-col">
        <div className="flex justify-between items-start mb-2">
          <div>
            <h3 className="text-xl font-heading font-bold text-white mb-1">
              {vehicle.brand} {vehicle.model}
            </h3>
            <div className="text-primary font-bold text-lg">
              ${vehicle.price.toLocaleString()}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3 mt-4 mb-6">
          <div className="flex items-center gap-2 text-sm text-secondary">
            <Calendar size={14} className="text-muted" />
            {vehicle.year}
          </div>
          <div className="flex items-center gap-2 text-sm text-secondary">
            <Settings size={14} className="text-muted" />
            {vehicle.engine}
          </div>
          <div className="flex items-center gap-2 text-sm text-secondary">
            <Fuel size={14} className="text-muted" />
            {vehicle.fuel}
          </div>
          <div className="flex items-center gap-2 text-sm text-secondary">
            <MapPin size={14} className="text-muted" />
            <span className="truncate">{vehicle.city.split(',')[0]}</span>
          </div>
        </div>

        <div className="mt-auto pt-4 border-t border-white/10">
          <Link to={`/vehiculo/${vehicle.id}`}>
            <Button variant="ghost" fullWidth rightIcon={<ArrowRight size={16} />} className="justify-between px-2 hover:bg-white/5">
              Ver detalles
            </Button>
          </Link>
        </div>
      </div>
    </Card>
  );
}
