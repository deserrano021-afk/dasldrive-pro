import { MapPin, X } from 'lucide-react';
import { useState } from 'react';
import { Input } from '../../components/Input';

export function LocationModal({ onClose, onSave, CITIES }: { onClose: () => void, onSave: (city: string) => void, CITIES: string[] }) {
  const [search, setSearch] = useState('');
  
  const filteredCities = CITIES.filter(c => c.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-card w-full max-w-md rounded-xl shadow-2xl overflow-hidden border border-white/10 flex flex-col" style={{ backgroundColor: 'var(--bg-card)' }}>
        <div className="p-4 border-b border-white/10 flex justify-between items-center">
          <h3 className="text-xl font-heading font-semibold flex items-center gap-2">
            <MapPin className="text-primary" />
            ¿Dónde te encuentras?
          </h3>
          <button onClick={onClose} className="text-muted hover:text-white transition-colors">
            <X size={20} />
          </button>
        </div>
        
        <div className="p-4 flex-1">
          <p className="text-secondary text-sm mb-4">
            Selecciona tu ubicación para mostrarte los vehículos disponibles en tu ciudad. (Simulación de Google Maps)
          </p>
          
          <Input 
            placeholder="Buscar ciudad... ej. San Pedro Sula" 
            leftIcon={<MapPin size={18} />}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="mb-4"
          />

          <div className="flex flex-col gap-2 max-h-60 overflow-y-auto pr-2">
            {filteredCities.map(city => (
              <button
                key={city}
                onClick={() => onSave(city)}
                className="text-left px-4 py-3 rounded-lg hover:bg-white/5 transition-colors border border-transparent hover:border-white/10 flex items-center justify-between group"
              >
                <span>{city}</span>
                <span className="text-primary opacity-0 group-hover:opacity-100 transition-opacity text-sm">Seleccionar</span>
              </button>
            ))}
            {filteredCities.length === 0 && (
              <div className="text-center py-4 text-muted">No se encontraron ciudades</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
