import { useState, useEffect } from 'react';

const CITIES = [
  'La Ceiba, Honduras',
  'San Pedro Sula, Honduras',
  'Tegucigalpa, Honduras',
  'San José, Costa Rica',
  'Ciudad de Guatemala, Guatemala',
  'San Salvador, El Salvador'
];

export function useLocationPrompt() {
  const [userLocation, setUserLocation] = useState<string | null>(null);
  const [showPrompt, setShowPrompt] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem('dasldrive_user_location');
    if (saved) {
      setUserLocation(saved);
    } else {
      // Simulate delay before showing prompt
      const timer = setTimeout(() => setShowPrompt(true), 1500);
      return () => clearTimeout(timer);
    }
  }, []);

  const saveLocation = (city: string) => {
    localStorage.setItem('dasldrive_user_location', city);
    setUserLocation(city);
    setShowPrompt(false);
  };

  return { userLocation, showPrompt, setShowPrompt, saveLocation, CITIES };
}
