import { useState } from 'react';
import { MessageSquarePlus } from 'lucide-react';
import { Button } from '../../components/Button';
import { Input } from '../../components/Input';
import { DbService } from '../../services/dbService';

export function SuggestionsBox() {
  const [isOpen, setIsOpen] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [success, setSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !message) return;
    
    DbService.saveSuggestion({
      id: `sug_${Date.now()}`,
      name,
      email,
      message,
      createdAt: new Date().toISOString()
    });
    
    setSuccess(true);
    setTimeout(() => {
      setIsOpen(false);
      setSuccess(false);
      setName('');
      setEmail('');
      setMessage('');
    }, 2000);
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {isOpen ? (
        <div className="bg-card w-80 rounded-xl shadow-2xl border border-white/10 overflow-hidden animate-fade-in flex flex-col" style={{ backgroundColor: 'var(--bg-card)' }}>
          <div className="bg-gradient-to-r from-primary to-primary-hover p-4 text-white flex justify-between items-center">
            <h4 className="font-semibold flex items-center gap-2">
              <MessageSquarePlus size={18} /> Buzón de Sugerencias
            </h4>
            <button onClick={() => setIsOpen(false)} className="hover:text-white/80">✕</button>
          </div>
          
          <div className="p-4">
            {success ? (
              <div className="text-center py-6 text-accent">
                <p className="font-semibold mb-1">¡Gracias por tus comentarios!</p>
                <p className="text-sm text-secondary">Nos ayudan a mejorar la plataforma.</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <p className="text-xs text-secondary mb-2">Ayúdanos a mejorar contándonos tu experiencia o sugiriendo nuevas funciones.</p>
                <Input 
                  placeholder="Tu Nombre (Opcional)" 
                  value={name}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setName(e.target.value)}
                />
                <Input 
                  type="email" 
                  placeholder="Tu Correo (Requerido)" 
                  required
                  value={email}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEmail(e.target.value)}
                />
                <textarea 
                  className="base-input w-full min-h-[100px] resize-none text-sm"
                  placeholder="Escribe tu sugerencia aquí..."
                  required
                  value={message}
                  onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setMessage(e.target.value)}
                />
                <Button type="submit" fullWidth>Enviar Sugerencia</Button>
              </form>
            )}
          </div>
        </div>
      ) : (
        <button 
          onClick={() => setIsOpen(true)}
          className="bg-primary hover:bg-primary-hover text-white w-14 h-14 rounded-full shadow-lg shadow-primary/30 flex items-center justify-center transition-transform hover:scale-105"
        >
          <MessageSquarePlus size={24} />
        </button>
      )}
    </div>
  );
}
