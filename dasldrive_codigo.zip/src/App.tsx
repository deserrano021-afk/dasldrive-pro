import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { MainLayout } from './layouts/MainLayout';
import { Home } from './pages/Home';
import { Marketplace } from './pages/Marketplace';
import { VehicleDetail } from './pages/VehicleDetail';
import { PublishVehicle } from './pages/PublishVehicle';
import { CopartService } from './pages/CopartService';
import { CopartRequestFlow } from './features/copart/CopartRequestFlow';
import { AdminDashboard } from './features/admin/AdminDashboard';
import { SuggestionsBox } from './features/shared/SuggestionsBox';

import { Login } from './pages/Login';
import { Register } from './pages/Register';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<MainLayout />}>
          <Route index element={<Home />} />
          <Route path="marketplace" element={<Marketplace />} />
          <Route path="vehiculo/:id" element={<VehicleDetail />} />
          <Route path="publicar" element={<PublishVehicle />} />
          
          <Route path="copart" element={<CopartService />} />
          <Route path="copart/:id" element={<CopartRequestFlow />} />
          
          <Route path="login" element={<Login />} />
          <Route path="registro" element={<Register />} />
        </Route>
        
        <Route path="/admin/*" element={<AdminDashboard />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
      <SuggestionsBox />
    </Router>
  );
}

export default App;
