import { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Upload, FileText, Camera, Car, CheckCircle, ArrowRight } from 'lucide-react';
import { Button } from '../components/Button';
import { Input } from '../components/Input';
import { Card } from '../components/Card';
import { AuthService } from '../services/authService';
import { DbService } from '../services/dbService';
import type { VehicleCondition } from '../types';

export function PublishVehicle() {
  const navigate = useNavigate();
  const user = AuthService.getCurrentUser();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const docInputRef = useRef<HTMLInputElement>(null);

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  
  const [formData, setFormData] = useState({
    brand: '',
    model: '',
    year: new Date().getFullYear().toString(),
    condition: 'usado' as VehicleCondition,
    mileage: '',
    engine: '',
    fuel: '',
    city: '',
    price: '',
    description: ''
  });

  // Mocked state for files
  const [images, setImages] = useState<string[]>([]);
  const [docs, setDocs] = useState<string[]>([]);

  if (!user) {
    return (
      <div className="container py-20 text-center">
        <h2 className="text-2xl mb-4">Debes iniciar sesión para publicar</h2>
        <Button onClick={() => navigate('/login')}>Ir a Iniciar Sesión</Button>
      </div>
    );
  }

  // Handle mock image upload (converting to data URL for local storage demo)
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const newImages = Array.from(e.target.files).slice(0, 5 - images.length); // Max 5
      
      newImages.forEach(file => {
        const reader = new FileReader();
        reader.onloadend = () => {
          setImages(prev => [...prev, reader.result as string]);
        };
        reader.readAsDataURL(file);
      });
    }
  };

  // Handle mock doc upload
  const handleDocUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newDocs = Array.from(e.target.files).map(f => f.name);
      setDocs(prev => [...prev, ...newDocs]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    setTimeout(() => {
      const newVehicle = {
        id: `veh_${Date.now()}`,
        sellerId: user.id,
        images: images.length > 0 ? images : ['https://images.unsplash.com/photo-1549317661-bd32c8ce0be2?q=80&w=800&auto=format&fit=crop'],
        documents: docs,
        brand: formData.brand,
        model: formData.model,
        year: parseInt(formData.year),
        condition: formData.condition,
        mileage: parseInt(formData.mileage) || 0,
        engine: formData.engine,
        fuel: formData.fuel,
        city: formData.city,
        price: parseFloat(formData.price),
        description: formData.description.slice(0, 150),
        createdAt: new Date().toISOString()
      };

      DbService.saveVehicle(newVehicle);
      setIsSubmitting(false);
      setSuccess(true);
    }, 1500);
  };

  if (success) {
    return (
      <div className="container py-20 flex justify-center">
        <Card className="max-w-md w-full p-8 text-center animate-fade-in">
          <div className="w-20 h-20 bg-accent/20 text-accent rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle size={40} />
          </div>
          <h2 className="text-2xl font-bold mb-4">¡Vehículo Publicado!</h2>
          <p className="text-secondary mb-8">Tu publicación ya está disponible en el marketplace.</p>
          <div className="flex gap-4">
            <Button variant="outline" fullWidth onClick={() => navigate('/portal')}>Ir a mi portal</Button>
            <Button fullWidth onClick={() => navigate('/marketplace')}>Ver en Marketplace</Button>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="container py-10 max-w-4xl">
      <div className="mb-8 flex items-center gap-3">
        <div className="w-12 h-12 bg-primary/20 text-primary rounded-xl flex items-center justify-center">
          <Car size={24} />
        </div>
        <div>
          <h1 className="text-3xl font-heading font-bold">Publicar Vehículo</h1>
          <p className="text-secondary">Ingresa los datos para vender o alquilar tu auto.</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8 animate-fade-in">
        
        {/* Basic Data */}
        <Card className="p-6">
          <h3 className="text-xl font-semibold mb-6 border-b border-white/10 pb-2">Datos Principales</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="md:col-span-2">
              <label className="text-sm text-secondary mb-2 block">Estado del vehículo</label>
              <div className="flex gap-4">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="radio" checked={formData.condition === 'nuevo'} onChange={() => setFormData({...formData, condition: 'nuevo'})} name="condition" />
                  <span>Nuevo</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="radio" checked={formData.condition === 'usado'} onChange={() => setFormData({...formData, condition: 'usado'})} name="condition" />
                  <span>Usado</span>
                </label>
              </div>
            </div>

            <Input required label="Marca" placeholder="Ej. Toyota" value={formData.brand} onChange={e => setFormData({...formData, brand: e.target.value})} />
            <Input required label="Modelo" placeholder="Ej. Hilux" value={formData.model} onChange={e => setFormData({...formData, model: e.target.value})} />
            <Input required type="number" label="Año" placeholder="2024" value={formData.year} onChange={e => setFormData({...formData, year: e.target.value})} />
            <Input required type="number" label="Kilometraje" placeholder="0" value={formData.mileage} onChange={e => setFormData({...formData, mileage: e.target.value})} disabled={formData.condition === 'nuevo'} />
            <Input required label="Motor" placeholder="Ej. 2.8 Diesel" value={formData.engine} onChange={e => setFormData({...formData, engine: e.target.value})} />
            <Input required label="Combustible" placeholder="Ej. Diesel, Gasolina, Híbrido" value={formData.fuel} onChange={e => setFormData({...formData, fuel: e.target.value})} />
            <Input required label="Ciudad" placeholder="Ej. San Pedro Sula" value={formData.city} onChange={e => setFormData({...formData, city: e.target.value})} />
            <Input required type="number" label="Precio ($)" placeholder="15000" value={formData.price} onChange={e => setFormData({...formData, price: e.target.value})} />
            
            <div className="md:col-span-2">
              <label className="text-sm text-secondary mb-2 block cursor-pointer">Otras características (Máximo 150 caracteres)</label>
              <textarea 
                className="base-input w-full min-h-[100px] resize-none" 
                placeholder="Llantas nuevas, mantenimiento al día, único dueño..."
                maxLength={150}
                value={formData.description}
                onChange={e => setFormData({...formData, description: e.target.value})}
              />
              <div className="text-right text-xs text-muted mt-1">{formData.description.length}/150</div>
            </div>
          </div>
        </Card>

        {/* Media */}
        <Card className="p-6">
          <h3 className="text-xl font-semibold mb-6 border-b border-white/10 pb-2">Imágenes y Documentos</h3>
          
          <div className="mb-8">
            <label className="text-sm text-secondary block mb-3">Fotos del Vehículo</label>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
              {images.map((img, i) => (
                <div key={i} className="aspect-square rounded-lg overflow-hidden border border-white/10 relative group">
                  <img src={img} alt={`Preview ${i}`} className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                     <button type="button" onClick={() => setImages(images.filter((_, idx) => idx !== i))} className="text-danger hover:text-white bg-white/10 p-2 rounded-full">
                       <Upload size={16} className="rotate-180" />
                     </button>
                  </div>
                </div>
              ))}
              {images.length < 5 && (
                <button 
                  type="button" 
                  onClick={() => fileInputRef.current?.click()}
                  className="aspect-square rounded-lg border-2 border-dashed border-white/20 hover:border-primary/50 text-muted hover:text-primary transition-colors flex flex-col items-center justify-center gap-2 bg-white/5"
                >
                  <Camera size={24} />
                  <span className="text-xs">Añadir Foto</span>
                </button>
              )}
            </div>
            <input type="file" multiple accept="image/*" className="hidden" ref={fileInputRef} onChange={handleImageUpload} />
          </div>

          <div>
            <label className="text-sm text-secondary block mb-3">Documentos (Opcional - Tarjeta de circulación, etc.)</label>
            <div className="flex flex-col gap-3">
              {docs.map((doc, i) => (
                <div key={i} className="flex items-center gap-3 bg-white/5 p-3 rounded-lg border border-white/10">
                  <FileText size={18} className="text-primary" />
                  <span className="text-sm flex-1 truncate">{doc}</span>
                  <button type="button" onClick={() => setDocs(docs.filter((_, idx) => idx !== i))} className="text-muted hover:text-danger">
                    ✕
                  </button>
                </div>
              ))}
              <Button type="button" variant="outline" size="sm" onClick={() => docInputRef.current?.click()} leftIcon={<Upload size={16} />} className="w-fit">
                Subir Documentos
              </Button>
            </div>
            <input type="file" multiple accept=".pdf,.doc,.docx" className="hidden" ref={docInputRef} onChange={handleDocUpload} />
            <p className="text-xs text-muted mt-2">Los documentos solo serán visibles para el administrador.</p>
          </div>
        </Card>

        {/* Submit */}
        <div className="flex justify-end pt-4">
          <Button type="submit" size="lg" isLoading={isSubmitting} rightIcon={!isSubmitting && <ArrowRight size={18} />}>
            Publicar Vehículo
          </Button>
        </div>
      </form>
    </div>
  );
}
