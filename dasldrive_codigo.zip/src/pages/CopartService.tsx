import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Gavel, ArrowRight } from 'lucide-react';
import { Button } from '../components/Button';
import { Card } from '../components/Card';
import { Input } from '../components/Input';
import { AuthService } from '../services/authService';
import { DbService } from '../services/dbService';
import type { CopartRequest } from '../types';

export function CopartService() {
  const navigate = useNavigate();
  const user = AuthService.getCurrentUser();
  const [activeRequests, setActiveRequests] = useState<CopartRequest[]>([]);

  useEffect(() => {
    if (user) {
      const myReqs = DbService.getCopartRequests().filter(r => r.clientId === user.id);
      setActiveRequests(myReqs);
    }
  }, [user]);

  const [copartLink, setCopartLink] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleRequest = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      navigate('/login');
      return;
    }
    if (!copartLink) return;

    setIsSubmitting(true);
    setTimeout(() => {
      const newReq: CopartRequest = {
        id: `cpt_${Date.now()}`,
        clientId: user.id,
        copartLink,
        status: 'pendiente_pago_servicio',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      DbService.saveCopartRequest(newReq);
      setIsSubmitting(false);
      navigate(`/copart/${newReq.id}`);
    }, 1000);
  };

  return (
    <div className="container py-12">
      {/* Hero */}
      <div className="text-center max-w-3xl mx-auto mb-16">
        <div className="w-20 h-20 bg-primary/20 text-primary rounded-full flex items-center justify-center mx-auto mb-6">
          <Gavel size={40} />
        </div>
        <h1 className="text-4xl md:text-5xl font-heading font-bold mb-6">
          Servicio de Compras Copart
        </h1>
        <p className="text-lg text-secondary">
          Actuamos como tus intermediarios de confianza. Encuentra tu vehículo en Copart, envíanos el enlace y nosotros nos encargamos del proceso de subasta por ti.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto mb-16">
        {/* How it works */}
        <div>
          <h2 className="text-2xl font-semibold mb-6">¿Cómo funciona?</h2>
          <div className="space-y-6">
            <div className="flex gap-4">
               <div className="w-8 h-8 rounded-full bg-primary/20 text-primary flex items-center justify-center flex-shrink-0 font-bold">1</div>
               <div>
                  <h4 className="font-semibold mb-1">Busca tu vehículo en Copart.com</h4>
                  <p className="text-sm text-secondary">Encuentra el auto de tus sueños y copia el enlace de la subasta.</p>
               </div>
            </div>
            <div className="flex gap-4">
               <div className="w-8 h-8 rounded-full bg-primary/20 text-primary flex items-center justify-center flex-shrink-0 font-bold">2</div>
               <div>
                  <h4 className="font-semibold mb-1">Envía tu solicitud y paga el servicio</h4>
                  <p className="text-sm text-secondary">Pega el enlace aquí. Te cobraremos una tarifa base por intermediario para habilitar el chat directo con nuestros agentes.</p>
               </div>
            </div>
            <div className="flex gap-4">
               <div className="w-8 h-8 rounded-full bg-primary/20 text-primary flex items-center justify-center flex-shrink-0 font-bold">3</div>
               <div>
                  <h4 className="font-semibold mb-1">Define tu puja y transfiere el monto</h4>
                  <p className="text-sm text-secondary">Coordina con nuestro equipo el monto máximo a pujar y transfiere los fondos requeridos.</p>
               </div>
            </div>
          </div>
        </div>

        {/* Request Form */}
        <Card className="p-8 border-primary/20 shadow-lg shadow-primary/5">
          <h3 className="text-xl font-bold mb-4">Comenzar Proceso</h3>
          {activeRequests.length > 0 && (
            <div className="mb-6 p-4 bg-white/5 rounded-lg border border-white/10">
              <h4 className="text-sm font-semibold mb-2">Tus solicitudes activas:</h4>
              <div className="space-y-2">
                {activeRequests.map(req => (
                  <Link key={req.id} to={`/copart/${req.id}`} className="flex items-center justify-between p-2 hover:bg-white/5 rounded-md text-sm transition-colors">
                    <span className="truncate max-w-[200px] text-primary">{req.id}</span>
                    <ArrowRight size={14} className="text-muted" />
                  </Link>
                ))}
              </div>
            </div>
          )}

          <form onSubmit={handleRequest} className="space-y-4">
            <Input 
              label="Enlace del vehículo Copart"
              placeholder="https://www.copart.com/lot/..."
              required
              value={copartLink}
              onChange={e => setCopartLink(e.target.value)}
            />
            <Button size="lg" fullWidth type="submit" isLoading={isSubmitting}>
              Enviar Solicitud
            </Button>
            {!user && <p className="text-xs text-center text-muted">Te pediremos iniciar sesión en el siguiente paso.</p>}
          </form>
        </Card>
      </div>
      
    </div>
  );
}
