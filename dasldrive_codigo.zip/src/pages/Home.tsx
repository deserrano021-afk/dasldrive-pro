import { Link } from 'react-router-dom';
import { ArrowRight, Car, Search, ShieldCheck } from 'lucide-react';
import { Button } from '../components/Button';
import { useLocationPrompt } from '../features/shared/useLocationPrompt';
import { LocationModal } from '../features/shared/LocationModal';
import './Home.css';

export function Home() {
  const { userLocation, showPrompt, setShowPrompt, saveLocation, CITIES } = useLocationPrompt();

  return (
    <div className="home-container">
      {showPrompt && (
        <LocationModal 
          onClose={() => setShowPrompt(false)} 
          onSave={saveLocation} 
          CITIES={CITIES} 
        />
      )}

      {/* Hero Section */}
      <section className="hero-section relative overflow-hidden">
        <div className="hero-bg-glow"></div>
        <div className="container relative z-10 pt-20 pb-32 flex flex-col items-center text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass border-primary/30 mb-8 animate-fade-in text-sm font-medium">
            <span className="w-2 h-2 rounded-full bg-primary animate-pulse"></span>
            La plataforma automotriz líder en {userLocation ? userLocation : 'Centroamérica'}
          </div>
          
          <h1 className="text-5xl md:text-7xl font-bold mb-6 max-w-4xl tracking-tight animate-fade-in" style={{ animationDelay: '100ms' }}>
            Encuentra el vehículo de tus <span className="text-gradient">sueños</span> hoy
          </h1>
          
          <p className="text-lg md:text-xl text-secondary mb-10 max-w-2xl animate-fade-in" style={{ animationDelay: '200ms' }}>
            Compra, vende o alquila vehículos con facilidad. Además, te ayudamos a importar directamente desde las subastas de Copart a tu ciudad.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 animate-fade-in" style={{ animationDelay: '300ms' }}>
            <Link to="/marketplace">
              <Button size="lg" rightIcon={<ArrowRight size={18} />}>
                Explorar Marketplace
              </Button>
            </Link>
            <Link to="/copart">
              <Button variant="secondary" size="lg" leftIcon={<Car size={18} />}>
                Servicio Copart
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-20 bg-card/30 border-y border-white/5">
        <div className="container">
          <div className="grid md:grid-cols-3 gap-8">
            <div className="glass-card p-8 flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center text-primary mb-6">
                <Search size={32} />
              </div>
              <h3 className="text-xl mb-3">Marketplace Inteligente</h3>
              <p className="text-muted text-sm">
                Filtra por marca, año, precio y ciudad para encontrar exactamente lo que buscas en nuestro amplio catálogo.
              </p>
            </div>
            
            <div className="glass-card p-8 flex flex-col items-center text-center border-primary/20">
              <div className="w-16 h-16 rounded-full bg-primary flex items-center justify-center text-white mb-6 shadow-lg shadow-primary/30">
                <Car size={32} />
              </div>
              <h3 className="text-xl mb-3">Subastas Copart</h3>
              <p className="text-muted text-sm">
                Actuamos como intermediarios para que puedas pujar y comprar vehículos a precios increíbles directamente de USA.
              </p>
            </div>

            <div className="glass-card p-8 flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-full bg-accent/10 flex items-center justify-center text-accent mb-6">
                <ShieldCheck size={32} />
              </div>
              <h3 className="text-xl mb-3">Conexión Segura</h3>
              <p className="text-muted text-sm">
                Contacta directamente con los vendedores a través de nuestra plataforma optimizada para tu comodidad.
              </p>
            </div>
          </div>
        </div>
      </section>

    </div>
  );
}
