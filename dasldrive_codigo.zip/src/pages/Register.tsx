import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { UserPlus, ArrowRight } from 'lucide-react';
import { Input } from '../components/Input';
import { Button } from '../components/Button';
import { Card } from '../components/Card';
import { AuthService } from '../services/authService';

export function Register() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    names: '',
    lastNames: '',
    email: '',
    phone: '',
    password: ''
  });
  const [error, setError] = useState('');

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.names || !formData.lastNames || !formData.email || !formData.phone || !formData.password) {
      setError('Por favor llena todos los campos');
      return;
    }

    const newUser = {
      id: `usr_${Date.now()}`,
      names: formData.names,
      lastNames: formData.lastNames,
      email: formData.email,
      phone: formData.phone,
      role: 'CLIENT' as const,
      createdAt: new Date().toISOString()
    };

    AuthService.login(newUser);
    navigate('/');
  };

  return (
    <div className="container py-20 flex justify-center items-center min-h-[calc(100vh-350px)]">
      <Card className="w-full max-w-lg p-8 animate-fade-in">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-primary/10 text-primary rounded-full flex items-center justify-center mx-auto mb-4">
            <UserPlus size={32} />
          </div>
          <h1 className="text-3xl font-heading font-bold">Crear Cuenta</h1>
          <p className="text-secondary mt-2">Únete a DASLDRIVE hoy mismo</p>
        </div>

        {error && (
          <div className="bg-danger/10 border border-danger/20 text-danger px-4 py-3 rounded-md mb-6 text-sm text-center">
            {error}
          </div>
        )}

        <form onSubmit={handleRegister} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <Input 
              label="Nombres"
              placeholder="Juan"
              value={formData.names}
              onChange={e => setFormData({...formData, names: e.target.value})}
            />
            <Input 
              label="Apellidos"
              placeholder="Pérez"
              value={formData.lastNames}
              onChange={e => setFormData({...formData, lastNames: e.target.value})}
            />
          </div>
          <Input 
            label="Correo Electrónico"
            type="email"
            placeholder="tu@correo.com"
            value={formData.email}
            onChange={e => setFormData({...formData, email: e.target.value})}
          />
          <Input 
            label="Número de Celular"
            type="tel"
            placeholder="+504 9999-9999"
            value={formData.phone}
            onChange={e => setFormData({...formData, phone: e.target.value})}
          />
          <Input 
            label="Contraseña"
            type="password"
            placeholder="Crea una contraseña segura"
            value={formData.password}
            onChange={e => setFormData({...formData, password: e.target.value})}
          />
          
          <div className="pt-4">
            <Button type="submit" fullWidth size="lg" rightIcon={<ArrowRight size={18} />}>
              Completar Registro
            </Button>
          </div>
        </form>

        <div className="mt-8 text-center text-sm text-secondary">
          ¿Ya tienes una cuenta? <Link to="/login" className="text-primary hover:underline">Inicia sesión</Link>
        </div>
      </Card>
    </div>
  );
}
