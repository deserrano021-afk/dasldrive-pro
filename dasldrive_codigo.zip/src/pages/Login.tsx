import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { LogIn, ArrowRight } from 'lucide-react';
import { Input } from '../components/Input';
import { Button } from '../components/Button';
import { Card } from '../components/Card';
import { AuthService } from '../services/authService';

export function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setError('Por favor llena todos los campos');
      return;
    }

    // Attempt mock login
    const users = AuthService.getAllUsers();
    const user = users.find(u => u.email === email);
    
    // Auto-create admin if it doesn't exist for test purposes
    if (email === 'admin@dasldrive.com' && !user) {
      const admin = {
        id: 'admin_1',
        names: 'Admin',
        lastNames: 'System',
        email: 'admin@dasldrive.com',
        phone: '0000',
        role: 'ADMIN' as const,
        createdAt: new Date().toISOString()
      };
      AuthService.login(admin);
      navigate('/admin');
      return;
    }

    if (user) {
      AuthService.login(user);
      navigate(user.role === 'ADMIN' ? '/admin' : '/');
    } else {
      setError('Credenciales inválidas o usuario no registrado.');
    }
  };

  return (
    <div className="container py-20 flex justify-center items-center min-h-[calc(100vh-350px)]">
      <Card className="w-full max-w-md p-8 animate-fade-in">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-primary/10 text-primary rounded-full flex items-center justify-center mx-auto mb-4">
            <LogIn size={32} />
          </div>
          <h1 className="text-3xl font-heading font-bold">Bienvenido</h1>
          <p className="text-secondary mt-2">Inicia sesión en tu cuenta</p>
        </div>

        {error && (
          <div className="bg-danger/10 border border-danger/20 text-danger px-4 py-3 rounded-md mb-6 text-sm text-center">
            {error}
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-4">
          <Input 
            label="Correo Electrónico"
            type="email"
            placeholder="tu@correo.com"
            value={email}
            onChange={e => setEmail(e.target.value)}
          />
          <Input 
            label="Contraseña"
            type="password"
            placeholder="••••••••"
            value={password}
            onChange={e => setPassword(e.target.value)}
          />
          
          <div className="pt-4">
            <Button type="submit" fullWidth size="lg" rightIcon={<ArrowRight size={18} />}>
              Ingresar
            </Button>
          </div>
        </form>

        <div className="mt-8 text-center text-sm text-secondary">
          ¿No tienes una cuenta? <Link to="/registro" className="text-primary hover:underline">Regístrate aquí</Link>
        </div>
        
        <div className="mt-4 text-center text-xs text-muted border-t border-white/10 pt-4">
          Para pruebas admin: admin@dasldrive.com / cualquier pass
        </div>
      </Card>
    </div>
  );
}
