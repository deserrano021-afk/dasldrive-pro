import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { MapPin, Calendar, Settings, Fuel, MessageCircle, ArrowLeft, Image as ImageIcon } from 'lucide-react';
import { DbService } from '../services/dbService';
import { Button } from '../components/Button';
import type { Vehicle } from '../types';

export function VehicleDetail() {
  const { id } = useParams<{ id: string }>();
  const [vehicle, setVehicle] = useState<Vehicle | null>(null);
  const [activeImage, setActiveImage] = useState(0);

  useEffect(() => {
    if (id) {
      const v = DbService.getVehicles().find(v => v.id === id);
      setVehicle(v || null);
    }
  }, [id]);

  if (!vehicle) {
    return (
      <div className="container py-20 text-center">
        <h2 className="text-2xl mb-4">Vehículo no encontrado</h2>
        <Link to="/marketplace">
          <Button variant="outline" leftIcon={<ArrowLeft size={18} />}>Volver al Marketplace</Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="container py-8">
      <Link to="/marketplace" className="inline-flex items-center text-sm text-secondary hover:text-white mb-6 transition-colors">
        <ArrowLeft size={16} className="mr-1" /> Volver al Marketplace
      </Link>

      <div className="flex flex-col lg:flex-row gap-8">
        
        {/* Gallery Section */}
        <div className="w-full lg:w-3/5 space-y-4">
          <div className="aspect-video w-full rounded-xl overflow-hidden glass border-white/10 relative">
            {vehicle.images.length > 0 ? (
              <img 
                src={vehicle.images[activeImage]} 
                alt={`${vehicle.brand} ${vehicle.model}`} 
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full flex flex-col items-center justify-center text-muted">
                <ImageIcon size={48} className="mb-2 opacity-50" />
                <span>Sin imágenes</span>
              </div>
            )}
            <div className="absolute top-4 right-4 bg-black/60 backdrop-blur px-3 py-1 rounded-full text-sm border border-white/20 uppercase">
              {vehicle.condition}
            </div>
          </div>
          
          {vehicle.images.length > 1 && (
            <div className="flex gap-4 overflow-x-auto pb-2">
              {vehicle.images.map((img, idx) => (
                <button 
                  key={idx}
                  onClick={() => setActiveImage(idx)}
                  className={`w-24 h-16 rounded-lg overflow-hidden flex-shrink-0 border-2 transition-all ${activeImage === idx ? 'border-primary opacity-100 scale-105' : 'border-transparent opacity-60 hover:opacity-100'}`}
                >
                  <img src={img} alt="Thumbnail" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Details Section */}
        <div className="w-full lg:w-2/5 flex flex-col">
          <div className="glass-card p-6 md:p-8 flex-1">
            <h1 className="text-3xl md:text-4xl font-heading font-bold mb-2">
              {vehicle.brand} {vehicle.model}
            </h1>
            <div className="text-3xl text-primary font-bold mb-6">
              ${vehicle.price.toLocaleString()}
            </div>

            <div className="grid grid-cols-2 gap-y-6 gap-x-4 mb-8">
              <div className="flex flex-col gap-1">
                <span className="text-sm text-muted flex items-center gap-1"><Calendar size={14} /> Año</span>
                <span className="font-semibold text-lg">{vehicle.year}</span>
              </div>
              <div className="flex flex-col gap-1">
                <span className="text-sm text-muted flex items-center gap-1"><Settings size={14} /> Motor</span>
                <span className="font-semibold text-lg">{vehicle.engine}</span>
              </div>
              <div className="flex flex-col gap-1">
                <span className="text-sm text-muted flex items-center gap-1"><Fuel size={14} /> Combustible</span>
                <span className="font-semibold text-lg">{vehicle.fuel}</span>
              </div>
              <div className="flex flex-col gap-1">
                <span className="text-sm text-muted flex items-center gap-1">Milaje</span>
                <span className="font-semibold text-lg">{vehicle.mileage.toLocaleString()} kms</span>
              </div>
            </div>

            <div className="mb-8 border-t border-white/10 pt-6">
              <span className="text-sm text-muted flex items-center gap-1 mb-2"><MapPin size={14} /> Ubicación</span>
              <p className="font-medium text-lg">{vehicle.city}</p>
            </div>

            <div className="mb-8 border-t border-white/10 pt-6">
              <h3 className="font-semibold mb-2">Descripción Adicional</h3>
              <p className="text-secondary leading-relaxed bg-black/20 p-4 rounded-lg border border-white/5">
                {vehicle.description || 'Sin descripción adicional.'}
              </p>
            </div>

            <Button 
              size="lg" 
              fullWidth 
              leftIcon={<MessageCircle size={20} />}
              className="mt-auto shadow-lg shadow-primary/20"
              onClick={() => alert(`Simulando contacto con el vendedor (ID: ${vehicle.sellerId})`)}
            >
              Contactar vendedor
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
