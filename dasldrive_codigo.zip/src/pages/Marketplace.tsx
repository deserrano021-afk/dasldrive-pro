import { useState, useEffect, useMemo } from 'react';
import { Search, SlidersHorizontal } from 'lucide-react';
import { VehicleCard } from '../features/marketplace/VehicleCard';
import { DbService } from '../services/dbService';
import { Input } from '../components/Input';
import type { Vehicle } from '../types';

// Mock data generator for testing if DB is empty
const MOCK_VEHICLES: Vehicle[] = [
  {
    id: 'v1', sellerId: 'u1', images: ['https://images.unsplash.com/photo-1552519507-da3b142c6e3d?q=80&w=800&auto=format&fit=crop'],
    documents: [], brand: 'Toyota', model: 'Hilux', year: 2022, condition: 'usado', mileage: 45000,
    engine: '2.8L Diesel', fuel: 'Diesel', city: 'San Pedro Sula, Honduras', price: 35000,
    description: 'Excelente estado, mantenimientos al día, único dueño.', createdAt: new Date().toISOString()
  },
  {
    id: 'v2', sellerId: 'u2', images: ['https://images.unsplash.com/photo-1606664515524-ed2f786a0b16?q=80&w=800&auto=format&fit=crop'],
    documents: [], brand: 'Honda', model: 'Civic', year: 2024, condition: 'nuevo', mileage: 0,
    engine: '1.5L Turbo', fuel: 'Gasolina', city: 'La Ceiba, Honduras', price: 28000,
    description: 'Recién importado, cero kilómetros, garantía de fábrica.', createdAt: new Date().toISOString()
  },
  {
    id: 'v3', sellerId: 'u3', images: ['https://images.unsplash.com/photo-1549317661-bd32c8ce0be2?q=80&w=800&auto=format&fit=crop'],
    documents: [], brand: 'Ford', model: 'Ranger', year: 2020, condition: 'usado', mileage: 75000,
    engine: '3.2L Diesel', fuel: 'Diesel', city: 'San José, Costa Rica', price: 25000,
    description: 'Llantas nuevas, excelente para trabajo.', createdAt: new Date().toISOString()
  }
];

export function Marketplace() {
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filters, setFilters] = useState({
    brand: '',
    year: '',
    minPrice: '',
    maxPrice: '',
    fuel: '',
    condition: '',
    city: ''
  });

  useEffect(() => {
    let dbVechicles = DbService.getVehicles();
    if (dbVechicles.length === 0) {
      MOCK_VEHICLES.forEach(v => DbService.saveVehicle(v));
      dbVechicles = DbService.getVehicles();
    }
    setVehicles(dbVechicles);

    // Initial city filter from location prompt
    const savedLoc = localStorage.getItem('dasldrive_user_location');
    if (savedLoc) {
      setFilters(prev => ({ ...prev, city: savedLoc }));
    }
  }, []);

  const filteredVehicles = useMemo(() => {
    return vehicles.filter(v => {
      const matchSearch = searchTerm === '' || 
        v.brand.toLowerCase().includes(searchTerm.toLowerCase()) || 
        v.model.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchBrand = filters.brand === '' || v.brand.toLowerCase() === filters.brand.toLowerCase();
      const matchYear = filters.year === '' || v.year.toString() === filters.year;
      const matchCondition = filters.condition === '' || v.condition === filters.condition;
      const matchFuel = filters.fuel === '' || v.fuel.toLowerCase() === filters.fuel.toLowerCase();
      const matchCity = filters.city === '' || v.city.toLowerCase().includes(filters.city.toLowerCase());
      
      const price = v.price;
      const minP = filters.minPrice ? parseInt(filters.minPrice) : 0;
      const maxP = filters.maxPrice ? parseInt(filters.maxPrice) : Infinity;
      const matchPrice = price >= minP && price <= maxP;

      return matchSearch && matchBrand && matchYear && matchCondition && matchFuel && matchCity && matchPrice;
    });
  }, [vehicles, searchTerm, filters]);

  // Extract unique values for filters
  const brands = [...new Set(vehicles.map(v => v.brand))];
  const years = [...new Set(vehicles.map(v => v.year))].sort((a,b) => b - a);
  const cities = [...new Set(vehicles.map(v => v.city))];

  return (
    <div className="container py-8 flex flex-col lg:flex-row gap-8">
      
      {/* Sidebar Filters */}
      <aside className="w-full lg:w-72 flex-shrink-0">
        <div className="glass-card p-6 sticky top-24">
          <div className="flex items-center gap-2 mb-6 border-b border-white/10 pb-4">
            <SlidersHorizontal size={20} className="text-primary" />
            <h2 className="text-lg font-heading font-semibold">Filtros</h2>
          </div>

          <div className="space-y-5">
            <div>
              <label className="text-sm text-secondary mb-2 block">Ubicación</label>
              <select 
                className="base-input w-full"
                value={filters.city}
                onChange={e => setFilters({...filters, city: e.target.value})}
              >
                <option value="">Todas las ciudades</option>
                {cities.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>

            <div>
              <label className="text-sm text-secondary mb-2 block">Marca</label>
              <select 
                className="base-input w-full"
                value={filters.brand}
                onChange={e => setFilters({...filters, brand: e.target.value})}
              >
                <option value="">Todas las marcas</option>
                {brands.map(b => <option key={b} value={b}>{b}</option>)}
              </select>
            </div>

            <div>
              <label className="text-sm text-secondary mb-2 block">Año</label>
              <select 
                className="base-input w-full"
                value={filters.year}
                onChange={e => setFilters({...filters, year: e.target.value})}
              >
                <option value="">Todos los años</option>
                {years.map(y => <option key={y} value={y.toString()}>{y}</option>)}
              </select>
            </div>

            <div>
              <label className="text-sm text-secondary mb-2 block">Estado</label>
              <div className="flex gap-2">
                <button 
                  className={`flex-1 py-2 text-sm rounded-md border ${filters.condition === 'nuevo' ? 'bg-primary border-primary text-white' : 'border-white/20 text-secondary hover:bg-white/5'}`}
                  onClick={() => setFilters({...filters, condition: filters.condition === 'nuevo' ? '' : 'nuevo'})}
                >Nuevo</button>
                <button 
                  className={`flex-1 py-2 text-sm rounded-md border ${filters.condition === 'usado' ? 'bg-primary border-primary text-white' : 'border-white/20 text-secondary hover:bg-white/5'}`}
                  onClick={() => setFilters({...filters, condition: filters.condition === 'usado' ? '' : 'usado'})}
                >Usado</button>
              </div>
            </div>

            <div>
              <label className="text-sm text-secondary mb-2 block">Precio ($)</label>
              <div className="flex gap-2">
                <Input 
                  type="number" 
                  placeholder="Min" 
                  value={filters.minPrice}
                  onChange={e => setFilters({...filters, minPrice: e.target.value})}
                />
                <Input 
                  type="number" 
                  placeholder="Max" 
                  value={filters.maxPrice}
                  onChange={e => setFilters({...filters, maxPrice: e.target.value})}
                />
              </div>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Grid */}
      <div className="flex-1">
        <div className="mb-8 flex flex-col sm:flex-row gap-4 justify-between items-center">
          <h1 className="text-3xl font-heading font-bold">Vehículos Disponibles</h1>
          <div className="w-full sm:w-72">
            <Input 
              placeholder="Buscar marca o modelo..." 
              leftIcon={<Search size={18} />}
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
            />
          </div>
        </div>

        {filteredVehicles.length === 0 ? (
          <div className="text-center py-20 glass-card">
            <h3 className="text-xl mb-2">No se encontraron vehículos</h3>
            <p className="text-muted">Intenta ajustar los filtros de búsqueda o cambiar tu ubicación.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {filteredVehicles.map(vehicle => (
              <VehicleCard key={vehicle.id} vehicle={vehicle} />
            ))}
          </div>
        )}
      </div>

    </div>
  );
}
