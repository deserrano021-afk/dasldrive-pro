import type { Vehicle, CopartRequest, ChatMessage, Suggestion, BankAccount } from '../types';

export const DbService = {
  // Vehicles
  getVehicles(): Vehicle[] {
    const data = localStorage.getItem('dasldrive_vehicles');
    return data ? JSON.parse(data) : [];
  },
  saveVehicle(vehicle: Vehicle) {
    const vehicles = this.getVehicles();
    vehicles.push(vehicle);
    localStorage.setItem('dasldrive_vehicles', JSON.stringify(vehicles));
  },
  
  // Copart Requests
  getCopartRequests(): CopartRequest[] {
    const data = localStorage.getItem('dasldrive_copart');
    return data ? JSON.parse(data) : [];
  },
  saveCopartRequest(req: CopartRequest) {
    const reqs = this.getCopartRequests();
    reqs.push(req);
    localStorage.setItem('dasldrive_copart', JSON.stringify(reqs));
  },
  updateCopartRequest(updatedReq: CopartRequest) {
    const reqs = this.getCopartRequests().map(r => r.id === updatedReq.id ? updatedReq : r);
    localStorage.setItem('dasldrive_copart', JSON.stringify(reqs));
  },

  // Chats
  getChats(requestId: string): ChatMessage[] {
    const data = localStorage.getItem('dasldrive_chats_' + requestId);
    return data ? JSON.parse(data) : [];
  },
  saveChatMessage(requestId: string, msg: ChatMessage) {
    const chats = this.getChats(requestId);
    chats.push(msg);
    localStorage.setItem('dasldrive_chats_' + requestId, JSON.stringify(chats));
  },

  // Suggestions
  getSuggestions(): Suggestion[] {
    const data = localStorage.getItem('dasldrive_suggestions');
    return data ? JSON.parse(data) : [];
  },
  saveSuggestion(suggestion: Suggestion) {
    const sug = this.getSuggestions();
    sug.push(suggestion);
    localStorage.setItem('dasldrive_suggestions', JSON.stringify(sug));
  },

  // Bank Accounts
  getBankAccounts(): BankAccount[] {
    const data = localStorage.getItem('dasldrive_banks');
    return data ? JSON.parse(data) : [];
  },
  saveBankAccount(account: BankAccount) {
    const accs = this.getBankAccounts();
    accs.push(account);
    localStorage.setItem('dasldrive_banks', JSON.stringify(accs));
  },
  deleteBankAccount(id: string) {
    const banks = this.getBankAccounts();
    const filtered = banks.filter(b => b.id !== id);
    localStorage.setItem('dasldrive_banks', JSON.stringify(filtered));
  }
};
