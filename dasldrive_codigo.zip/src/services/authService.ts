import type { User } from '../types';

export const AuthService = {
  getCurrentUser(): User | null {
    const data = localStorage.getItem('dasldrive_currentUser');
    return data ? JSON.parse(data) : null;
  },

  login(user: User) {
    localStorage.setItem('dasldrive_currentUser', JSON.stringify(user));
    // Also save in full user array if not exists
    const users = this.getAllUsers();
    if (!users.find(u => u.id === user.id)) {
      users.push(user);
      localStorage.setItem('dasldrive_users', JSON.stringify(users));
    }
  },

  logout() {
    localStorage.removeItem('dasldrive_currentUser');
  },

  getAllUsers(): User[] {
    const data = localStorage.getItem('dasldrive_users');
    return data ? JSON.parse(data) : [];
  }
};
