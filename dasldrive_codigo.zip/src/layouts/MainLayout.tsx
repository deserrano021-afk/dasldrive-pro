import { Outlet, Link, useNavigate } from 'react-router-dom';
import { Car, Menu, X, Gavel, LogOut, User as UserIcon } from 'lucide-react';
import { useState, useEffect } from 'react';
import { Button } from '../components/Button';
import { AuthService } from '../services/authService';
import type { User } from '../types';
import './MainLayout.css';

export function MainLayout() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const navigate = useNavigate();

  // Polling for demo simplicity or use proper context in real app
  useEffect(() => {
    const checkUser = () => {
      setUser(AuthService.getCurrentUser());
    };
    checkUser();
    window.addEventListener('storage', checkUser);
    const interval = setInterval(checkUser, 1000);
    return () => {
      window.removeEventListener('storage', checkUser);
      clearInterval(interval);
    };
  }, []);

  const handleLogout = () => {
    AuthService.logout();
    navigate('/');
  };

  return (
    <div className="layout-wrapper">
      {/* Navbar */}
      <header className="navbar glass">
        <div className="container navbar-container">
          <Link to="/" className="logo">
            <div className="logo-icon-wrap">
              <Car size={24} className="text-white" />
            </div>
            <span className="logo-text">DASL<span className="text-primary">DRIVE</span></span>
          </Link>

          {/* Desktop Nav */}
          <nav className="desktop-nav">
            <Link to="/marketplace" className="nav-link">Marketplace</Link>
            <Link to="/copart" className="nav-link flex items-center gap-2">
              <Gavel size={16} /> Subastas Copart
            </Link>
            <div className="nav-divider" />
            {user ? (
              <div className="flex items-center gap-4">
                <Link to={user.role === 'ADMIN' ? '/admin' : '/portal'} className="flex items-center gap-2 text-sm font-medium hover:text-primary transition-colors">
                  <div className="w-8 h-8 rounded-full bg-primary/20 text-primary flex items-center justify-center">
                    <UserIcon size={16} />
                  </div>
                  <span>{user.names}</span>
                </Link>
                {user.role !== 'ADMIN' && (
                   <Link to="/publicar"><Button size="sm">Publicar</Button></Link>
                )}
                <button onClick={handleLogout} className="text-muted hover:text-danger transition-colors p-2" title="Cerrar sesión">
                  <LogOut size={18} />
                </button>
              </div>
            ) : (
              <>
                <Link to="/login"><Button variant="ghost" size="sm">Iniciar Sesión</Button></Link>
                <Link to="/registro"><Button variant="primary" size="sm">Registrarse</Button></Link>
              </>
            )}
          </nav>

          {/* Mobile Toggle */}
          <button 
            className="mobile-menu-btn"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Nav */}
        {isMobileMenuOpen && (
          <div className="mobile-nav glass">
            <Link to="/marketplace" className="mobile-nav-link" onClick={() => setIsMobileMenuOpen(false)}>Marketplace</Link>
            <Link to="/copart" className="mobile-nav-link" onClick={() => setIsMobileMenuOpen(false)}>Subastas Copart</Link>
            <div className="mobile-nav-actions">
               <Button variant="ghost" fullWidth>Iniciar Sesión</Button>
               <Button variant="primary" fullWidth>Registrarse</Button>
            </div>
          </div>
        )}
      </header>

      {/* Main Content Area */}
      <main className="main-content">
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="footer">
        <div className="container">
          <div className="footer-grid">
            <div className="footer-brand">
              <Link to="/" className="logo mb-4">
                <Car size={20} className="text-primary mr-2" />
                <span className="logo-text">DASL<span className="text-primary">DRIVE</span></span>
              </Link>
              <p className="footer-desc">
                Tu plataforma de confianza para la compra, venta y alquiler de vehículos, además de importación directa vía Copart.
              </p>
            </div>
            <div className="footer-links">
              <h4>Enlaces Rápidos</h4>
              <Link to="/marketplace">Marketplace</Link>
              <Link to="/copart">Servicio Copart</Link>
              <Link to="/login">Acceso Usuarios</Link>
            </div>
            <div className="footer-legal">
              <h4>Aviso Legal</h4>
              <p className="legal-notice text-xs text-muted">
                "DASLDRIVE funciona únicamente como una plataforma digital que conecta compradores, vendedores y arrendadores de vehículos. La empresa no participa directamente en las negociaciones, pagos o acuerdos finales entre los usuarios. Por lo tanto, DASLDRIVE no se responsabiliza por fraudes, estafas, información incorrecta publicada por terceros o conflictos derivados de las transacciones entre usuarios."
              </p>
            </div>
          </div>
          <div className="footer-bottom">
            <p>&copy; {new Date().getFullYear()} DASLDRIVE. Todos los derechos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
